# setNeedsLayout vs layoutIfNeeded Explained

This project accompanies the tutorial on my website here: http://www.iosinsight.com/setneedslayout-vs-layoutifneeded-explained/
